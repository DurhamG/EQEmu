source create_tables_content.sql;
source create_tables_login.sql;
source create_tables_player.sql;
source create_tables_queryserv.sql;
source create_tables_state.sql;
source create_tables_system.sql;
