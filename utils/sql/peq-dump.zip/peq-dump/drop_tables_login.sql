DROP TABLE IF EXISTS `login_accounts`;
DROP TABLE IF EXISTS `login_api_tokens`;
DROP TABLE IF EXISTS `login_server_admins`;
DROP TABLE IF EXISTS `login_server_list_types`;
DROP TABLE IF EXISTS `login_world_servers`;
