source drop_tables_content.sql;
source drop_tables_login.sql;
source drop_tables_player.sql;
source drop_tables_queryserv.sql;
source drop_tables_state.sql;
source drop_tables_system.sql;
